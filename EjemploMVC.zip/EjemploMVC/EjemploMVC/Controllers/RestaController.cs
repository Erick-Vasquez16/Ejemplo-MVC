﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using EjemploMVC.Models;
using System.Web.Mvc;

namespace EjemploMVC.Controllers
{
    public class RestaController : Controller
    {
        // GET: Resta
        public ActionResult OperacionResta()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult OperacionResta(calculo obCalculo)
        {
            int Resultado = obCalculo.numero1 - obCalculo.numero2;
            ViewBag.resultado = Resultado;
            return View(obCalculo);
        }
    }
}